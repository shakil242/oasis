export default function ApplicationLogo() {
    return (
        <img src="/assets/img/logo.png" className="img-fluid" width={240} alt="logo" />
    );
}
