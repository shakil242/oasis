import { useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { Chart, ArcElement, Tooltip, Legend } from "chart.js";
import { a as jsx, F as Fragment } from "../ssr.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
Chart.register(ArcElement, Tooltip, Legend);
function CardTypeGraph() {
  const data = {
    datasets: [{
      label: "",
      data: [32, 14, 33, 0],
      backgroundColor: [
        "#5366cc",
        "#FF4069",
        "green",
        "#112B43"
      ],
      hoverOffset: 4
    }]
  };
  const [chartData, setChartData] = useState(data);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx(Doughnut, {
      data: chartData
    })
  });
}
export {
  CardTypeGraph as default
};
