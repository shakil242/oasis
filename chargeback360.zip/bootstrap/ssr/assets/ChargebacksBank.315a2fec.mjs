import "react";
import ChargebackBINsGraph from "./ChargebackBINsGraph.f2df6f27.mjs";
import CardType from "./CardType.c74b0e59.mjs";
import { j as jsxs, F as Fragment, a as jsx } from "../ssr.mjs";
import "chart.js";
import "react-chartjs-2";
import "./CardTypeGraph.48870648.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
function ChargebacksBank() {
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx("div", {
      className: "col-md-6 col-12 my-2",
      children: /* @__PURE__ */ jsxs("div", {
        className: "card shadow",
        children: [/* @__PURE__ */ jsx("div", {
          className: "card-header",
          children: /* @__PURE__ */ jsx("h6", {
            className: "mb-0",
            children: "Top 5 High Chargeback BINs"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "card-body",
          children: /* @__PURE__ */ jsx("div", {
            className: "row",
            children: /* @__PURE__ */ jsx("div", {
              className: "col-12",
              children: /* @__PURE__ */ jsx(ChargebackBINsGraph, {})
            })
          })
        })]
      })
    }), /* @__PURE__ */ jsx(CardType, {})]
  });
}
export {
  ChargebacksBank as default
};
