import { useState } from "react";
import { Chart, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from "chart.js";
import { Bar } from "react-chartjs-2";
import { a as jsx, F as Fragment } from "../ssr.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
Chart.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);
function BillingCycleGraph() {
  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "top"
      }
    }
  };
  const data = {
    labels: ["January", "February", "March", "April", "May", "June", "July"],
    datasets: [{
      label: "Billing Cycle",
      data: [380, 0, 30, 220, 0],
      backgroundColor: "#FF4069"
    }]
  };
  const [chartData, setChartData] = useState(data);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx(Bar, {
      options,
      data: chartData
    })
  });
}
export {
  BillingCycleGraph as default
};
