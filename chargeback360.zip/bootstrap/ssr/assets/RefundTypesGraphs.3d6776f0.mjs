import { useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { Chart, ArcElement, Tooltip, Legend } from "chart.js";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
Chart.register(ArcElement, Tooltip, Legend);
function RefundTypesGraphs() {
  const fullRefundData = {
    datasets: [{
      label: "Full refund",
      data: [89, 400],
      backgroundColor: ["green", "#EFEEEE"],
      hoverOffset: 4
    }]
  };
  const partialRefundData = {
    datasets: [{
      label: "Partial refund",
      data: [13, 400],
      backgroundColor: ["#FF4069", "#EFEEEE"],
      hoverOffset: 4
    }]
  };
  const noRefundData = {
    datasets: [{
      label: "Partial refund",
      data: [380, 60],
      backgroundColor: ["#1C3041", "#EFEEEE"],
      hoverOffset: 4
    }]
  };
  const [fullRefund, setfullRefund] = useState(fullRefundData);
  const [partialRefund, setpartialRefund] = useState(partialRefundData);
  const [noRefund, setnoRefund] = useState(noRefundData);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsxs("div", {
      className: "row",
      children: [/* @__PURE__ */ jsxs("div", {
        className: "col-md-4 col-sm-6 col-12 borderR--lightGray-1",
        children: [/* @__PURE__ */ jsx(Doughnut, {
          data: fullRefund
        }), /* @__PURE__ */ jsx("p", {
          className: "text-muted mb-0 small",
          children: "Total"
        }), /* @__PURE__ */ jsx("p", {
          className: "fw-500",
          children: "89 \xA0|\xA0 17.4%"
        })]
      }), /* @__PURE__ */ jsxs("div", {
        className: "col-md-4 col-sm-6 col-12 borderR--lightGray-1",
        children: [/* @__PURE__ */ jsx(Doughnut, {
          data: partialRefund
        }), /* @__PURE__ */ jsx("p", {
          className: "text-muted mb-0 small",
          children: "Total"
        }), /* @__PURE__ */ jsx("p", {
          className: "fw-500",
          children: "13 \xA0|\xA0 2.15%"
        })]
      }), /* @__PURE__ */ jsxs("div", {
        className: "col-md-4 col-sm-6 col-12",
        children: [/* @__PURE__ */ jsx(Doughnut, {
          data: noRefund
        }), /* @__PURE__ */ jsx("p", {
          className: "text-muted mb-0 small",
          children: "Total"
        }), /* @__PURE__ */ jsx("p", {
          className: "fw-500",
          children: "407 \xA0|\xA0 79.1%"
        })]
      })]
    })
  });
}
export {
  RefundTypesGraphs as default
};
