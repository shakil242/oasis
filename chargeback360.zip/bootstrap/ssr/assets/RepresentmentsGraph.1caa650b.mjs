import { useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { Chart, ArcElement, Tooltip, Legend } from "chart.js";
import { a as jsx, F as Fragment } from "../ssr.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
Chart.register(ArcElement, Tooltip, Legend);
function RepresentmentsGraph() {
  const data = {
    datasets: [{
      label: "",
      data: [228, 191, 73, 0, 0, 0],
      backgroundColor: ["#89043D", "#1C3041", "#B2ABF2", "#18F2B2", "#3DDC97", "red"],
      hoverOffset: 4
    }]
  };
  const [chartData, setChartData] = useState(data);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx(Doughnut, {
      data: chartData
    })
  });
}
export {
  RepresentmentsGraph as default
};
