import { useState } from "react";
import { Chart, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from "chart.js";
import { Bar } from "react-chartjs-2";
import { a as jsx, F as Fragment } from "../ssr.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
Chart.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);
function ChargebackBINsGraph() {
  const options = {
    indexAxis: "y",
    responsive: true,
    elements: {
      bar: {
        borderWidth: 0
      }
    },
    plugins: {
      legend: {
        position: false
      }
    }
  };
  const data = {
    labels: ["41479", "45894", "23498", "87674", "98735", "98623"],
    datasets: [{
      label: "",
      data: [0, 1, 2, 3, 4, 5, 6],
      backgroundColor: ["#FF4069", "#5366cc"]
    }]
  };
  const [chartData, setChartData] = useState(data);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx(Bar, {
      options,
      data: chartData
    })
  });
}
export {
  ChargebackBINsGraph as default
};
