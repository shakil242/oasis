import "react";
import RepresentmentsGraph from "./RepresentmentsGraph.1caa650b.mjs";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "react-chartjs-2";
import "chart.js";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
function Representments() {
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("div", {
      className: "col-md-6 col-12 my-2",
      children: /* @__PURE__ */ jsxs("div", {
        className: "card shadow",
        children: [/* @__PURE__ */ jsx("div", {
          className: "card-header",
          children: /* @__PURE__ */ jsx("h6", {
            className: "mb-0",
            children: "Representments"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "card-body",
          children: /* @__PURE__ */ jsxs("div", {
            className: "row",
            children: [/* @__PURE__ */ jsx("div", {
              className: "col-md-5 col-12",
              children: /* @__PURE__ */ jsx(RepresentmentsGraph, {})
            }), /* @__PURE__ */ jsxs("div", {
              className: "col-md-7 col-12",
              children: [/* @__PURE__ */ jsxs("div", {
                className: "row py-1",
                children: [/* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#89043D"
                    },
                    children: "Accepted"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "228"
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#18F2B2"
                    },
                    children: "Insurance"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "0"
                  })]
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "row py-1",
                children: [/* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "red"
                    },
                    children: "Loss"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "0"
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#3DDC97"
                    },
                    children: "Win"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "0"
                  })]
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "row py-1",
                children: [/* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#1C3041"
                    },
                    children: "Unknown"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "191"
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#B2ABF2"
                    },
                    children: "Pending"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "73"
                  })]
                })]
              })]
            })]
          })
        })]
      })
    })
  });
}
export {
  Representments as default
};
