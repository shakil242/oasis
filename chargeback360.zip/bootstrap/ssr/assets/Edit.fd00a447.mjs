import { A as Authenticated } from "./AuthenticatedLayout.1ce58590.mjs";
import DeleteUserForm from "./DeleteUserForm.5de426da.mjs";
import UpdatePasswordForm from "./UpdatePasswordForm.ce3179c7.mjs";
import UpdateProfileInformation from "./UpdateProfileInformationForm.f486baad.mjs";
import { Head } from "@inertiajs/inertia-react";
import { j as jsxs, a as jsx } from "../ssr.mjs";
import "react";
import "./ApplicationLogo.74ab7505.mjs";
import "./Dropdown.3a6a16a7.mjs";
import "@headlessui/react";
import "./TextInput.b898353a.mjs";
import "./InputLabel.ff764233.mjs";
import "./PrimaryButton.1304be79.mjs";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Edit({
  auth,
  mustVerifyEmail,
  status
}) {
  return /* @__PURE__ */ jsxs(Authenticated, {
    auth,
    header: /* @__PURE__ */ jsx("h2", {
      className: "font-semibold text-xl text-gray-800 leading-tight",
      children: "Profile"
    }),
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Profile"
    }), /* @__PURE__ */ jsx("div", {
      className: "py-12",
      children: /* @__PURE__ */ jsxs("div", {
        className: "max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6",
        children: [/* @__PURE__ */ jsx("div", {
          className: "p-4 sm:p-8 bg-white shadow sm:rounded-lg",
          children: /* @__PURE__ */ jsx(UpdateProfileInformation, {
            mustVerifyEmail,
            status,
            className: "max-w-xl"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "p-4 sm:p-8 bg-white shadow sm:rounded-lg",
          children: /* @__PURE__ */ jsx(UpdatePasswordForm, {
            className: "max-w-xl"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "p-4 sm:p-8 bg-white shadow sm:rounded-lg",
          children: /* @__PURE__ */ jsx(DeleteUserForm, {
            className: "max-w-xl"
          })
        })]
      })
    })]
  });
}
export {
  Edit as default
};
