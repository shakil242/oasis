import { a as jsx } from "../ssr.mjs";
function ApplicationLogo() {
  return /* @__PURE__ */ jsx("img", {
    src: "/assets/img/logo.png",
    className: "img-fluid",
    width: 240,
    alt: "logo"
  });
}
export {
  ApplicationLogo as A
};
