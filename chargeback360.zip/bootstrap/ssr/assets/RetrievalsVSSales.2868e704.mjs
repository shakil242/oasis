import "@inertiajs/inertia-react";
import "react";
import RetrievalsVSSalesGraph from "./RetrievalsVSSalesGraph.c0866351.mjs";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "chart.js";
import "react-chartjs-2";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function RetrievalsVSSales() {
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("div", {
      className: "col-md-6 col-12 my-2",
      children: /* @__PURE__ */ jsxs("div", {
        className: "card shadow",
        children: [/* @__PURE__ */ jsx("div", {
          className: "card-header",
          children: /* @__PURE__ */ jsx("h6", {
            className: "mb-0",
            children: "Retrievals vs Sales"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "card-body",
          children: /* @__PURE__ */ jsxs("div", {
            className: "row",
            children: [/* @__PURE__ */ jsx("div", {
              className: "col-md-8 col-12",
              children: /* @__PURE__ */ jsx(RetrievalsVSSalesGraph, {})
            }), /* @__PURE__ */ jsxs("div", {
              className: "col-md-4 col-12",
              children: [/* @__PURE__ */ jsx("p", {
                className: "h6 mb-0 h6",
                style: {
                  color: "#FF4069"
                },
                children: "Retrievals"
              }), /* @__PURE__ */ jsx("p", {
                className: "h6 text-muted mb-0 small",
                children: "Total"
              }), /* @__PURE__ */ jsx("p", {
                className: "fw-500",
                children: "6274"
              }), /* @__PURE__ */ jsx("p", {
                className: "h6 mb-0 h6",
                style: {
                  color: "#5366cc"
                },
                children: "Sales"
              }), /* @__PURE__ */ jsx("p", {
                className: "h6 text-muted mb-0 small",
                children: "Total"
              }), /* @__PURE__ */ jsx("p", {
                className: "fw-500",
                children: "3098"
              })]
            })]
          })
        })]
      })
    })
  });
}
export {
  RetrievalsVSSales as default
};
