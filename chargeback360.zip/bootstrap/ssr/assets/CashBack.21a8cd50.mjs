import "react";
import ChargebacksVsSales from "./ChargebacksVsSales.efd5ca71.mjs";
import Representments from "./Representments.67c9d02b.mjs";
import BillingCycle from "./BillingCycle.a7c49340.mjs";
import MIDs from "./MIDs.62956cb0.mjs";
import RefundTypes from "./RefundTypes.02ccd466.mjs";
import RetrievalsVSSales from "./RetrievalsVSSales.2868e704.mjs";
import ChargebacksBank from "./ChargebacksBank.315a2fec.mjs";
import ServiceProvider from "./ServiceProvider.78d27c56.mjs";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "@inertiajs/inertia-react";
import "./ChargebacksVsSalesGraph.85e07cb4.mjs";
import "react-chartjs-2";
import "chart.js";
import "./RepresentmentsGraph.1caa650b.mjs";
import "./BillingCycleGraph.ca1a675a.mjs";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
import "./MIDsTable.b677d735.mjs";
import "cdbreact";
import "./RefundTypesGraphs.3d6776f0.mjs";
import "./RetrievalsVSSalesGraph.c0866351.mjs";
import "./ChargebackBINsGraph.f2df6f27.mjs";
import "./CardType.c74b0e59.mjs";
import "./CardTypeGraph.48870648.mjs";
import "./ReasonCode.407670fd.mjs";
import "./ReasonCodeGraph.652c4ce3.mjs";
import "./PerformanceMetric.d966fc86.mjs";
import "./PerformanceMetricGraph.1280a3e6.mjs";
import "./CB_ByProduct.548b0164.mjs";
import "./CB_Monthly.613404cb.mjs";
import "./CB_MonthlyGraph.80d28fac.mjs";
function CashBack() {
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("main", {
      className: "mt-80 mainSection",
      children: /* @__PURE__ */ jsx("div", {
        className: "container-fluid",
        children: /* @__PURE__ */ jsxs("div", {
          className: "row cashBack",
          children: [/* @__PURE__ */ jsx("h4", {
            className: "text-muted text-center my-3",
            children: "CashBack"
          }), /* @__PURE__ */ jsx(ChargebacksVsSales, {}), /* @__PURE__ */ jsx(Representments, {}), /* @__PURE__ */ jsx(BillingCycle, {}), /* @__PURE__ */ jsx(MIDs, {}), /* @__PURE__ */ jsx(RefundTypes, {}), /* @__PURE__ */ jsx(RetrievalsVSSales, {}), /* @__PURE__ */ jsx("h4", {
            className: "text-muted text-center my-3",
            children: "Chargebacks by Bank"
          }), /* @__PURE__ */ jsx(ChargebacksBank, {}), /* @__PURE__ */ jsx("h4", {
            className: "text-muted text-center my-3",
            children: "Chargebacks by Service Providers"
          }), /* @__PURE__ */ jsx(ServiceProvider, {})]
        })
      })
    })
  });
}
export {
  CashBack as default
};
