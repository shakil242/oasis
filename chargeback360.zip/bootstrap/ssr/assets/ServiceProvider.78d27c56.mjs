import "react";
import ReasonCode from "./ReasonCode.407670fd.mjs";
import PerformanceMetric from "./PerformanceMetric.d966fc86.mjs";
import CB_ByProduct from "./CB_ByProduct.548b0164.mjs";
import CB_Monthly from "./CB_Monthly.613404cb.mjs";
import { j as jsxs, F as Fragment, a as jsx } from "../ssr.mjs";
import "./ReasonCodeGraph.652c4ce3.mjs";
import "chart.js";
import "react-chartjs-2";
import "./PerformanceMetricGraph.1280a3e6.mjs";
import "cdbreact";
import "./CB_MonthlyGraph.80d28fac.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
function ServiceProvider() {
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx(ReasonCode, {}), /* @__PURE__ */ jsx(PerformanceMetric, {}), /* @__PURE__ */ jsx(CB_ByProduct, {}), /* @__PURE__ */ jsx(CB_Monthly, {})]
  });
}
export {
  ServiceProvider as default
};
