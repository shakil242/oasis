import "react";
import PerformanceMetricGraph from "./PerformanceMetricGraph.1280a3e6.mjs";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "react-chartjs-2";
import "chart.js";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
function PerformanceMetric() {
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("div", {
      className: "col-md-6 col-12 my-2",
      children: /* @__PURE__ */ jsxs("div", {
        className: "card shadow",
        children: [/* @__PURE__ */ jsx("div", {
          className: "card-header",
          children: /* @__PURE__ */ jsx("h6", {
            className: "mb-0",
            children: "Call Center Performance Metrics"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "card-body",
          children: /* @__PURE__ */ jsxs("div", {
            className: "row",
            children: [/* @__PURE__ */ jsx("div", {
              className: "col-md-5 col-12",
              children: /* @__PURE__ */ jsx(PerformanceMetricGraph, {})
            }), /* @__PURE__ */ jsxs("div", {
              className: "col-md-7 col-12",
              children: [/* @__PURE__ */ jsxs("div", {
                className: "row py-1",
                children: [/* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#FFB915"
                    },
                    children: "Live Rep"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "50"
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#1C3041"
                    },
                    children: "RMA"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "0"
                  })]
                })]
              }), /* @__PURE__ */ jsx("div", {
                className: "row py-1",
                children: /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#89043D"
                    },
                    children: "No Call"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "489"
                  })]
                })
              })]
            })]
          })
        })]
      })
    })
  });
}
export {
  PerformanceMetric as default
};
