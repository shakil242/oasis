import { Link } from "@inertiajs/inertia-react";
import { D as Dropdown } from "./Dropdown.3a6a16a7.mjs";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "react";
import "@headlessui/react";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Header({
  userInfo
}) {
  const firstLetter = userInfo.name.slice(0, 1);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("header", {
      className: "bg-blue-gradient p-fixed--header shadow",
      children: /* @__PURE__ */ jsx("nav", {
        className: "navbar navbar-expand-lg px-md-2",
        children: /* @__PURE__ */ jsxs("div", {
          className: "container-fluid d-md-flex justify-content-md-between",
          children: [/* @__PURE__ */ jsx(Link, {
            className: "navbar-brand d-flex",
            href: "#",
            children: /* @__PURE__ */ jsx("img", {
              src: "assets/img/logo.png",
              className: "img-fluid",
              alt: true,
              srcSet: true
            })
          }), /* @__PURE__ */ jsx("button", {
            className: "navbar-toggler",
            type: "button",
            "data-bs-toggle": "collapse",
            "data-bs-target": "#navbarSupportedContent",
            "aria-controls": "navbarSupportedContent",
            "aria-expanded": "false",
            "aria-label": "Toggle navigation",
            children: /* @__PURE__ */ jsx("span", {
              className: "navbar-toggler-icon"
            })
          }), /* @__PURE__ */ jsx("div", {
            className: "collapse navbar-collapse",
            id: "navbarSupportedContent",
            children: /* @__PURE__ */ jsxs("ul", {
              className: "navbar-nav ms-auto mb-2 mb-lg-0",
              children: [/* @__PURE__ */ jsx("li", {
                className: "nav-item",
                children: /* @__PURE__ */ jsx("p", {
                  className: "m-0 nav-link",
                  children: /* @__PURE__ */ jsx("input", {
                    type: "date",
                    className: "form-control datePickH",
                    id: "dateHeader"
                  })
                })
              }), /* @__PURE__ */ jsx("li", {
                className: "nav-item",
                children: /* @__PURE__ */ jsx("p", {
                  className: "m-0 nav-link",
                  children: /* @__PURE__ */ jsx("input", {
                    type: "date",
                    className: "form-control datePickH",
                    id: "dateHeader"
                  })
                })
              }), /* @__PURE__ */ jsxs("li", {
                className: "nav-item dropdown",
                children: [/* @__PURE__ */ jsxs(Link, {
                  className: "nav-link dropdown-toggle",
                  href: "#",
                  id: "navbarDropdown",
                  role: "button",
                  "data-bs-toggle": "dropdown",
                  "aria-expanded": "false",
                  children: [/* @__PURE__ */ jsx("span", {
                    className: "user-letter",
                    children: firstLetter
                  }), /* @__PURE__ */ jsx("span", {
                    children: userInfo.name
                  })]
                }), /* @__PURE__ */ jsxs("ul", {
                  className: "dropdown-menu",
                  "aria-labelledby": "navbarDropdown",
                  children: [/* @__PURE__ */ jsx("li", {
                    children: /* @__PURE__ */ jsx(Link, {
                      className: "dropdown-item",
                      href: "#",
                      children: /* @__PURE__ */ jsxs(Dropdown.Link, {
                        href: route("profile.edit"),
                        children: [/* @__PURE__ */ jsx("i", {
                          className: "fa-solid fa-lock pe-2"
                        }), " Change password"]
                      })
                    })
                  }), /* @__PURE__ */ jsx("li", {
                    children: /* @__PURE__ */ jsxs(Link, {
                      className: "dropdown-item",
                      href: "#",
                      children: [/* @__PURE__ */ jsx("i", {
                        className: "fa-solid fa-circle-info pe-2"
                      }), " User guide"]
                    })
                  }), /* @__PURE__ */ jsx("li", {
                    children: /* @__PURE__ */ jsx("hr", {
                      className: "dropdown-divider"
                    })
                  }), /* @__PURE__ */ jsx("li", {
                    children: /* @__PURE__ */ jsx(Link, {
                      className: "dropdown-item",
                      children: /* @__PURE__ */ jsxs(Dropdown.Link, {
                        href: route("logout"),
                        method: "post",
                        as: "button",
                        children: [/* @__PURE__ */ jsx("i", {
                          className: "fa-solid fa-right-from-bracket pe-2"
                        }), "Log Out"]
                      })
                    })
                  })]
                })]
              })]
            })
          })]
        })
      })
    })
  });
}
export {
  Header as default
};
