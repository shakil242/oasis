import "react";
import ReasonCodeGraph from "./ReasonCodeGraph.652c4ce3.mjs";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "chart.js";
import "react-chartjs-2";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
function ReasonCode() {
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("div", {
      className: "col-md-6 col-12 my-2",
      children: /* @__PURE__ */ jsxs("div", {
        className: "card shadow",
        children: [/* @__PURE__ */ jsx("div", {
          className: "card-header",
          children: /* @__PURE__ */ jsx("h6", {
            className: "mb-0",
            children: "Chargebacks by Reason Codes"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "card-body",
          children: /* @__PURE__ */ jsx("div", {
            className: "row",
            children: /* @__PURE__ */ jsx("div", {
              className: "col-12",
              children: /* @__PURE__ */ jsx(ReasonCodeGraph, {})
            })
          })
        })]
      })
    })
  });
}
export {
  ReasonCode as default
};
