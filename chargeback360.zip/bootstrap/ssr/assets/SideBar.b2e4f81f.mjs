import { Link } from "@inertiajs/inertia-react";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function SideBar() {
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("aside", {
      id: "sideBar",
      className: "shadow",
      children: /* @__PURE__ */ jsxs("ul", {
        className: "list-unstyled",
        children: [/* @__PURE__ */ jsx("li", {
          className: "active",
          children: /* @__PURE__ */ jsxs(Link, {
            href: "",
            children: [/* @__PURE__ */ jsx("i", {
              className: "fa-sharp fa-solid fa-person-walking-arrow-loop-left"
            }), /* @__PURE__ */ jsx("span", {
              className: "h4",
              children: "CashBack"
            })]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            href: "",
            children: [/* @__PURE__ */ jsx("i", {
              className: "fa-sharp fa-solid fa-bell"
            }), /* @__PURE__ */ jsx("span", {
              className: "h4",
              children: "Alerts"
            })]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            href: "",
            children: [/* @__PURE__ */ jsx("i", {
              className: "fa-solid fa-chart-simple"
            }), /* @__PURE__ */ jsx("span", {
              className: "h4",
              children: "Analytics"
            })]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            href: "",
            children: [/* @__PURE__ */ jsx("i", {
              className: "fa-solid fa-database"
            }), /* @__PURE__ */ jsx("span", {
              className: "h4",
              children: "Data"
            })]
          })
        }), /* @__PURE__ */ jsx("li", {
          children: /* @__PURE__ */ jsxs(Link, {
            href: "",
            children: [/* @__PURE__ */ jsx("i", {
              className: "fa-solid fa-user"
            }), /* @__PURE__ */ jsx("span", {
              className: "h4",
              children: "Profiles"
            })]
          })
        })]
      })
    })
  });
}
export {
  SideBar as default
};
