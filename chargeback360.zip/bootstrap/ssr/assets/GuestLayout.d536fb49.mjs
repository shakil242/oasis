import { A as ApplicationLogo } from "./ApplicationLogo.74ab7505.mjs";
import { Link } from "@inertiajs/inertia-react";
import { j as jsxs, a as jsx } from "../ssr.mjs";
function Guest({
  children
}) {
  return /* @__PURE__ */ jsxs("div", {
    className: "loginBg d-flex flex-column justify-content-center",
    children: [/* @__PURE__ */ jsx(Link, {
      href: "/",
      className: "text-center d-block mb-4",
      children: /* @__PURE__ */ jsx(ApplicationLogo, {})
    }), /* @__PURE__ */ jsx("div", {
      className: "container-fluid",
      children: /* @__PURE__ */ jsx("div", {
        className: "row",
        children
      })
    })]
  });
}
export {
  Guest as G
};
