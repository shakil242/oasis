import { useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { Chart, ArcElement, Tooltip, Legend } from "chart.js";
import { j as jsxs, F as Fragment, a as jsx } from "../ssr.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
Chart.register(ArcElement, Tooltip, Legend);
function ChargebacksVsSalesGraph() {
  const data = {
    labels: ["Success sale", "Charge back"],
    datasets: [{
      label: "",
      data: [91.85, 8.15],
      backgroundColor: ["#FF4069", "#FFC234"],
      hoverOffset: 4
    }]
  };
  const [chartData, setChartData] = useState(data);
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx(Doughnut, {
      data: chartData
    }), /* @__PURE__ */ jsx("h5", {
      className: "h6 text-center mt-2",
      children: "Sales converted to Chargebacks"
    })]
  });
}
export {
  ChargebacksVsSalesGraph as default
};
