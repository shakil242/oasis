import CashBack from "./CashBack.21a8cd50.mjs";
import Header from "./Header.f3914662.mjs";
import SideBar from "./SideBar.b2e4f81f.mjs";
import { j as jsxs, F as Fragment, a as jsx } from "../ssr.mjs";
import "react";
import "./ChargebacksVsSales.efd5ca71.mjs";
import "@inertiajs/inertia-react";
import "./ChargebacksVsSalesGraph.85e07cb4.mjs";
import "react-chartjs-2";
import "chart.js";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
import "./Representments.67c9d02b.mjs";
import "./RepresentmentsGraph.1caa650b.mjs";
import "./BillingCycle.a7c49340.mjs";
import "./BillingCycleGraph.ca1a675a.mjs";
import "./MIDs.62956cb0.mjs";
import "./MIDsTable.b677d735.mjs";
import "cdbreact";
import "./RefundTypes.02ccd466.mjs";
import "./RefundTypesGraphs.3d6776f0.mjs";
import "./RetrievalsVSSales.2868e704.mjs";
import "./RetrievalsVSSalesGraph.c0866351.mjs";
import "./ChargebacksBank.315a2fec.mjs";
import "./ChargebackBINsGraph.f2df6f27.mjs";
import "./CardType.c74b0e59.mjs";
import "./CardTypeGraph.48870648.mjs";
import "./ServiceProvider.78d27c56.mjs";
import "./ReasonCode.407670fd.mjs";
import "./ReasonCodeGraph.652c4ce3.mjs";
import "./PerformanceMetric.d966fc86.mjs";
import "./PerformanceMetricGraph.1280a3e6.mjs";
import "./CB_ByProduct.548b0164.mjs";
import "./CB_Monthly.613404cb.mjs";
import "./CB_MonthlyGraph.80d28fac.mjs";
import "./Dropdown.3a6a16a7.mjs";
import "@headlessui/react";
function Dashboard(props) {
  const userInfo = props.auth.user;
  return /* @__PURE__ */ jsxs(Fragment, {
    children: [/* @__PURE__ */ jsx(Header, {
      userInfo
    }), /* @__PURE__ */ jsx(SideBar, {}), props.component === "CashBack" ? /* @__PURE__ */ jsx(CashBack, {}) : null]
  });
}
export {
  Dashboard as default
};
