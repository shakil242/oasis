import { useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { Chart, ArcElement, Tooltip, Legend } from "chart.js";
import { a as jsx, F as Fragment } from "../ssr.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
Chart.register(ArcElement, Tooltip, Legend);
function PerformanceMetricGraph() {
  const data = {
    datasets: [{
      label: "",
      data: [50, 0, 489],
      backgroundColor: ["#FFB915", "#1C3041", "#89043D"],
      hoverOffset: 4
    }]
  };
  const [chartData, setChartData] = useState(data);
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx(Doughnut, {
      data: chartData
    })
  });
}
export {
  PerformanceMetricGraph as default
};
