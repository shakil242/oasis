import "react";
import CardTypeGraph from "./CardTypeGraph.48870648.mjs";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "react-chartjs-2";
import "chart.js";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
function CardType() {
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("div", {
      className: "col-md-6 col-12 my-2",
      children: /* @__PURE__ */ jsxs("div", {
        className: "card shadow",
        children: [/* @__PURE__ */ jsx("div", {
          className: "card-header",
          children: /* @__PURE__ */ jsx("h6", {
            className: "mb-0",
            children: "Chargebacks by Card Types"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "card-body",
          children: /* @__PURE__ */ jsxs("div", {
            className: "row",
            children: [/* @__PURE__ */ jsx("div", {
              className: "col-md-5 col-12",
              children: /* @__PURE__ */ jsx(CardTypeGraph, {})
            }), /* @__PURE__ */ jsxs("div", {
              className: "col-md-7 col-12",
              children: [/* @__PURE__ */ jsxs("div", {
                className: "row py-1",
                children: [/* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#5366cc"
                    },
                    children: "Master Card"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "32"
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#FF4069"
                    },
                    children: "Visa Card"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "14"
                  })]
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "row py-1",
                children: [/* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "green"
                    },
                    children: "Discover Card"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "33"
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-6 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 mb-0 h6",
                    style: {
                      color: "#112B43"
                    },
                    children: "Amex Card"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "0"
                  })]
                })]
              })]
            })]
          })
        })]
      })
    })
  });
}
export {
  CardType as default
};
