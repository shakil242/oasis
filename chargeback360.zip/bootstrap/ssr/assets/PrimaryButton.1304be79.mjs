import { a as jsx } from "../ssr.mjs";
function PrimaryButton({
  type = "submit",
  className = "",
  processing,
  children,
  onClick
}) {
  return /* @__PURE__ */ jsx("button", {
    type,
    onClick,
    className: `btn btn-primary d-block ${processing} ` + className,
    disabled: processing,
    children
  });
}
export {
  PrimaryButton as P
};
