import { Link } from "@inertiajs/inertia-react";
import "react";
import ChargebacksVsSalesGraph from "./ChargebacksVsSalesGraph.85e07cb4.mjs";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "react-chartjs-2";
import "chart.js";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function ChargebacksVsSales() {
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("div", {
      className: "col-md-6 col-12 my-2",
      children: /* @__PURE__ */ jsxs("div", {
        className: "card shadow",
        children: [/* @__PURE__ */ jsx("div", {
          className: "card-header",
          children: /* @__PURE__ */ jsx("h6", {
            className: "mb-0",
            children: "Chargebacks Vs Sales"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "card-body",
          children: /* @__PURE__ */ jsxs("div", {
            className: "row",
            children: [/* @__PURE__ */ jsx("div", {
              className: "col-md-5 col-12",
              children: /* @__PURE__ */ jsx(ChargebacksVsSalesGraph, {})
            }), /* @__PURE__ */ jsxs("div", {
              className: "col-md-7 col-12",
              children: [/* @__PURE__ */ jsxs("div", {
                className: "row borderB--lightGray-1 py-2",
                children: [/* @__PURE__ */ jsx("div", {
                  className: "col-12",
                  children: /* @__PURE__ */ jsx("p", {
                    className: "text-primary mb-0 small",
                    children: "Chargebacks"
                  })
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-5 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total CBs"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "492 \xA0|\xA0 8.15%"
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-7 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "CBs Amount"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "$27,731.55 \xA0|\xA0 11.15%"
                  })]
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "row borderB--lightGray-1 py-2",
                children: [/* @__PURE__ */ jsx("div", {
                  className: "col-12",
                  children: /* @__PURE__ */ jsx(Link, {
                    href: "",
                    className: "text-primary small",
                    children: "CBs Vs Date Range Sales"
                  })
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-5 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total CBs"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "44 \xA0|\xA0 0.73%"
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-7 col-12 d-flex flex-column justify-content-end",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "CBs Amount"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "$2,634.37 \xA0|\xA0 5.15%"
                  })]
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "row py-2",
                children: [/* @__PURE__ */ jsx("div", {
                  className: "col-12",
                  children: /* @__PURE__ */ jsx("p", {
                    className: "text-primary mb-0 small",
                    children: "Chargebacks"
                  })
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-5 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "Total CBs"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "492 \xA0|\xA0 8.15%"
                  })]
                }), /* @__PURE__ */ jsxs("div", {
                  className: "col-sm-7 col-12",
                  children: [/* @__PURE__ */ jsx("p", {
                    className: "h6 text-muted mb-0 small",
                    children: "CBs Amount"
                  }), /* @__PURE__ */ jsx("p", {
                    className: "fw-500",
                    children: "$27,731.55 \xA0|\xA0 11.15%"
                  })]
                })]
              })]
            })]
          })
        })]
      })
    })
  });
}
export {
  ChargebacksVsSales as default
};
