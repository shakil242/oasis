import { useState, useMemo } from "react";
import { CDBContainer, CDBDataTable } from "cdbreact";
import { a as jsx, F as Fragment, j as jsxs } from "../ssr.mjs";
import "react-dom/server";
import "@inertiajs/inertia-react";
import "process";
import "http";
import "react/jsx-runtime";
function CB_ByProduct() {
  const [MIDsData, setMIDsData] = useState([{
    product_id: 1039,
    product_name: "ProSound Pods (R)",
    sales: "72-coolestma",
    cbs: 56,
    sales: 543,
    cb: "14.59%"
  }, {
    product_id: 1039,
    product_name: "ProSound Pods (R)",
    sales: "72-coolestma",
    cbs: 56,
    sales: 544,
    cb: "14.59%"
  }, {
    product_id: 1040,
    product_name: "ProSound Pods (R)",
    sales: "72-coolestma",
    cbs: 56,
    sales: 545,
    cb: "14.59%"
  }, {
    product_id: 1041,
    product_name: "ProSound Pods (R)",
    sales: "72-coolestma",
    cbs: 56,
    sales: 546,
    cb: "14.59%"
  }, {
    product_id: 1042,
    product_name: "ProSound Pods (R)",
    sales: "72-coolestma",
    cbs: 56,
    sales: 543,
    cb: "14.59%"
  }, {
    product_id: 1043,
    product_name: "ProSound Pods (R)",
    sales: "72-coolestma",
    cbs: 56,
    sales: 547,
    cb: "14.59%"
  }]);
  const data = () => {
    let sDataTable = {
      columns: [{
        label: "Product Id",
        field: "product_id",
        sort: "asc"
      }, {
        label: "Product Name",
        field: "product_name",
        sort: "asc"
      }, {
        label: "CBs",
        field: "cbs",
        sort: "asc"
      }, {
        label: "Sales",
        field: "sales",
        sort: "asc"
      }, {
        label: "CB %",
        field: "cb",
        sort: "asc"
      }],
      rows: []
    };
    function createRow() {
      MIDsData.forEach((pPost, i) => {
        sDataTable.rows.push({
          product_id: pPost.product_id,
          product_name: pPost.product_name,
          sales: pPost.sales,
          cbs: pPost.cbs,
          sales: pPost.sales,
          cb: pPost.cb
        });
      });
    }
    var returnData = useMemo(() => {
      createRow();
      return sDataTable;
    }, [MIDsData]);
    return returnData;
  };
  return /* @__PURE__ */ jsx(Fragment, {
    children: /* @__PURE__ */ jsx("div", {
      className: "col-md-6 col-12 my-2",
      children: /* @__PURE__ */ jsxs("div", {
        className: "card shadow",
        children: [/* @__PURE__ */ jsx("div", {
          className: "card-header",
          children: /* @__PURE__ */ jsx("h6", {
            className: "mb-0",
            children: "Chargebacks by Product"
          })
        }), /* @__PURE__ */ jsx("div", {
          className: "card-body",
          children: /* @__PURE__ */ jsx("div", {
            className: "row",
            children: /* @__PURE__ */ jsx("div", {
              className: "col-12 CBProducts",
              children: /* @__PURE__ */ jsx(CDBContainer, {
                style: {
                  maxHeight: "300px",
                  overflowY: "auto"
                },
                children: /* @__PURE__ */ jsx(CDBDataTable, {
                  bordered: true,
                  hover: true,
                  data: data(),
                  responsive: true
                })
              })
            })
          })
        })]
      })
    })
  });
}
export {
  CB_ByProduct as default
};
