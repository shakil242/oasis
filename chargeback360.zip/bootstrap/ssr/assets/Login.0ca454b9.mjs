import { useEffect } from "react";
import { G as Guest } from "./GuestLayout.d536fb49.mjs";
import { T as TextInput, I as InputError } from "./TextInput.b898353a.mjs";
import { I as InputLabel } from "./InputLabel.ff764233.mjs";
import { P as PrimaryButton } from "./PrimaryButton.1304be79.mjs";
import { useForm, Head, Link } from "@inertiajs/inertia-react";
import { j as jsxs, a as jsx } from "../ssr.mjs";
import "./ApplicationLogo.74ab7505.mjs";
import "react-dom/server";
import "process";
import "http";
import "react/jsx-runtime";
function Login({
  status,
  canResetPassword
}) {
  const {
    data,
    setData,
    post,
    processing,
    errors,
    reset
  } = useForm({
    email: "",
    password: "",
    remember: ""
  });
  useEffect(() => {
    return () => {
      reset("password");
    };
  }, []);
  const onHandleChange = (event) => {
    setData(event.target.name, event.target.type === "checkbox" ? event.target.checked : event.target.value);
  };
  const submit = (e) => {
    e.preventDefault();
    post(route("login"));
  };
  return /* @__PURE__ */ jsxs(Guest, {
    children: [/* @__PURE__ */ jsx(Head, {
      title: "Log in"
    }), status && /* @__PURE__ */ jsx("div", {
      className: "mb-4 font-medium text-sm text-green-600",
      children: status
    }), /* @__PURE__ */ jsx("div", {
      className: "col-md-6 col-10 mx-auto",
      children: /* @__PURE__ */ jsx("div", {
        className: "card shadow",
        children: /* @__PURE__ */ jsx("div", {
          className: "card-body",
          children: /* @__PURE__ */ jsxs("div", {
            className: "px-md-3 px-sm-2",
            children: [/* @__PURE__ */ jsx("h3", {
              className: "mb-4 text-center",
              children: "User Login"
            }), /* @__PURE__ */ jsxs("form", {
              onSubmit: submit,
              children: [/* @__PURE__ */ jsxs("div", {
                children: [/* @__PURE__ */ jsx(InputLabel, {
                  forInput: "email",
                  value: "Email"
                }), /* @__PURE__ */ jsx(TextInput, {
                  id: "email",
                  type: "email",
                  name: "email",
                  value: data.email,
                  className: "form-control",
                  autoComplete: "username",
                  isFocused: true,
                  handleChange: onHandleChange
                }), /* @__PURE__ */ jsx(InputError, {
                  message: errors.email,
                  className: "mt-2 text-danger"
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "mt-4",
                children: [/* @__PURE__ */ jsx(InputLabel, {
                  forInput: "password",
                  value: "Password"
                }), /* @__PURE__ */ jsx(TextInput, {
                  id: "password",
                  type: "password",
                  name: "password",
                  value: data.password,
                  className: "form-control",
                  autoComplete: "current-password",
                  handleChange: onHandleChange
                }), /* @__PURE__ */ jsx(InputError, {
                  message: errors.password,
                  className: "mt-2 text-danger"
                })]
              }), /* @__PURE__ */ jsxs("div", {
                className: "text-center mt-4",
                children: [/* @__PURE__ */ jsx(PrimaryButton, {
                  className: "loginBtn",
                  processing,
                  children: "Log in"
                }), canResetPassword && /* @__PURE__ */ jsx("button", {
                  className: "btn btn-default mt-2",
                  children: /* @__PURE__ */ jsx(Link, {
                    href: route("password.request"),
                    className: "text-decoration-none",
                    children: "Forgot password?"
                  })
                })]
              })]
            })]
          })
        })
      })
    })]
  });
}
export {
  Login as default
};
